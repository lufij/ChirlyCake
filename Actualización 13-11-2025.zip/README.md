
  # Pastelería Web App

  This is a code bundle for Pastelería Web App. The original project is available at https://www.figma.com/design/nI6xlzUt7zGDI2IsaDVytv/Pasteler%C3%ADa-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  